double recthexa_volume(double ** v)
{
  return 1./3.0;
};
