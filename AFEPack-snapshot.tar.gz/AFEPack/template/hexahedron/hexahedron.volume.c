double hexahedron_volume(double ** v)
{
  return 1.;
};
